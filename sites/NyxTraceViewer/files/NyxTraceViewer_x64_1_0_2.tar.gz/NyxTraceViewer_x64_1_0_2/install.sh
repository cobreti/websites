#!/bin/sh

cp ./libQtCore.so.4.8.1 /usr/lib
cp ./libQtGui.so.4.8.1 /usr/lib

[ ! -f /usr/lib/libQtCore.so.4 ] && ln -s /usr/lib/libQtCore.so.4.8.1 /usr/lib/libQtCore.so.4
[ ! -f /usr/lib/libQtGui.so.4 ] && ln -s /usr/lib/libQtGui.so.4.8.1 /usr/lib/libQtGui.so.4

