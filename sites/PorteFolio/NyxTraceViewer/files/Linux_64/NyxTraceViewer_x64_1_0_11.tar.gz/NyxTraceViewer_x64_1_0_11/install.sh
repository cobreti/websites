#!/bin/sh

cp ./libQtCore.so.5.0.1 /usr/lib
cp ./libQtGui.so.5.0.1 /usr/lib

[ ! -f /usr/lib/libQtCore.so.5 ] && ln -s /usr/lib/libQtCore.so.5.0.1 /usr/lib/libQtCore.so.5
[ ! -f /usr/lib/libQtGui.so.5 ] && ln -s /usr/lib/libQtGui.so.5.0.1 /usr/lib/libQtGui.so.5

