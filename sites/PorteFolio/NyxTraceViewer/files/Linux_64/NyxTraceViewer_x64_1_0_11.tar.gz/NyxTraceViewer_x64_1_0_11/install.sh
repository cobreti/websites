#!/bin/sh

cp ./libQt5Core.so.5.1.0 /usr/lib
cp ./libQt5Gui.so.5.1.0 /usr/lib
cp ./libQt5Widgets.so.5.1.0 /usr/lib
cp ./libicui18n.so.51.1 /usr/lib

[ ! -f /usr/lib/libQt5Core.so.5 ] && ln -s /usr/lib/libQt5Core.so.5.1.0 /usr/lib/libQt5Core.so.5
[ ! -f /usr/lib/libQt5Gui.so.5 ] && ln -s /usr/lib/libQt5Gui.so.5.1.0 /usr/lib/libQt5Gui.so.5
[ ! -f /usr/lib/libQt5Widgets.so.5 ] && ln -s /usr/lib/libQt5Widgets.so.5.1.0 /usr/lib/libQt5Widgets.so.5
[ ! -f /usr/lib/libicui18n.so.51 ] && ln -s /usr/lib/libicui18n.so.51.1 /usr/lib/libicui18n.so.51

