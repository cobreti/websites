#!/bin/sh

cp ./libQt5Core.so.5.0.1 /usr/lib
cp ./libQt5Gui.so.5.0.1 /usr/lib

[ ! -f /usr/lib/libQt5Core.so.5 ] && ln -s /usr/lib/libQt5Core.so.5.0.1 /usr/lib/libQt5Core.so.5
[ ! -f /usr/lib/libQt5Gui.so.5 ] && ln -s /usr/lib/libQt5Gui.so.5.0.1 /usr/lib/libQt5Gui.so.5

