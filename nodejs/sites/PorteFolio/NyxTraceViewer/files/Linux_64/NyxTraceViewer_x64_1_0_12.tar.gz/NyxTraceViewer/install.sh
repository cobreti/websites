#!/bin/sh

LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`; export LD_LIBRARY_PATH

ln -s libQt5Widgets.so.5.1.0 libQt5Widgets.so.5
ln -s libQt5Gui.so.5.1.0 libQt5Gui.so.5
ln -s libQt5Core.so.5.1.0 libQt5Core.so.5
ln -s libQt5DBus.so.5.1.0 libQt5DBus.so.5
ln -s libicuuc.so.51.1 libicuuc.so.51
ln -s libicui18n.so.51.1 libicui18n.so.51
ln -s libicudata.so.51.1 libicudata.so.51
