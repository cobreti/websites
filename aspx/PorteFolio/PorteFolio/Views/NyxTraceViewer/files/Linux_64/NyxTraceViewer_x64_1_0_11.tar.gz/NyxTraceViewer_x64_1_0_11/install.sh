#!/bin/sh

apt-get install qt5-default

